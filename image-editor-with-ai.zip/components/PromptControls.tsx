import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';

interface PromptControlsProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
  isImageUploaded: boolean;
}

export const PromptControls: React.FC<PromptControlsProps> = ({ prompt, setPrompt, onSubmit, isLoading, isImageUploaded }) => {
  const isDisabled = isLoading || !isImageUploaded;

  return (
    <div className="flex flex-col space-y-4">
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="e.g., 'Add a futuristic helmet to the person' or 'Change the background to a Martian landscape'..."
        className="w-full h-24 p-4 bg-gray-800 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none resize-none transition-colors"
        disabled={!isImageUploaded}
      />
      <button
        onClick={onSubmit}
        disabled={isDisabled}
        className="flex items-center justify-center w-full px-6 py-3 text-lg font-semibold text-white bg-purple-600 rounded-lg hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100"
      >
        <SparklesIcon className="w-6 h-6 mr-2" />
        {isLoading ? 'Generating...' : 'Apply Edit'}
      </button>
    </div>
  );
};
