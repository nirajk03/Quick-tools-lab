import { GoogleGenAI, Modality } from "@google/genai";
import type { EditImageResult } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function editImageWithGemini(
  base64ImageData: string,
  mimeType: string,
  prompt: string
): Promise<EditImageResult> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });

    const result: EditImageResult = {
      imageUrl: null,
      text: null,
    };

    if (response.candidates && response.candidates.length > 0) {
        const parts = response.candidates[0].content.parts;
        for (const part of parts) {
            if (part.inlineData) {
                const { data, mimeType } = part.inlineData;
                result.imageUrl = `data:${mimeType};base64,${data}`;
            } else if (part.text) {
                result.text = part.text;
            }
        }
    }

    if (!result.imageUrl) {
        throw new Error("API did not return an image. It might have refused the request.");
    }

    return result;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to edit image: ${error.message}`);
    }
    throw new Error("An unexpected error occurred while editing the image.");
  }
}
