export interface EditImageResult {
  imageUrl: string | null;
  text: string | null;
}
